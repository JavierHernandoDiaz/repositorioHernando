<?php
//VARIABLE DE SESION
session_start();
//CONTROLADOR FRONTAL//////
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//REQUIRES DE MODELOS , CONTROLADORES Y CONFIG 
require './app/config.php';
require './app/controlador/AnunciosController.php';
require './app/controlador/UsuariosController.php';
require './app/modelos/ConexionBD.php';
require './app/modelos/Anuncio.php';
require './app/modelos/AnuncioDAO.php';
require './app/modelos/Usuario.php';
require './app/modelos/UsuarioDAO.php';
require './app/modelos/Comentario.php';
require './app/modelos/ComentarioDAO.php';
require './app/modelos/Likes.php';
require './app/modelos/LikesDAO.php';
require './app/modelos/Seguidor.php';
require './app/modelos/SeguidorDAO.php';
require './app/utilidades/MensajeFlash.php';
//MAPA DE ENRUTAMIENTO
$map = array(
    "login" =>array("controller"=>"UsuariosController", "method"=> "login", "publica" =>true),
    "logout" =>array("controller"=>"UsuariosController", "method"=> "logout", "publica" =>false),
    "registrar" =>array("controller"=>"UsuariosController", "method"=> "registrar","publica" =>true),
    "insertar_anuncio" =>array("controller"=>"AnunciosController", "method"=> "insertar_anuncio","publica" =>false),
    "borrar_anuncio" =>array("controller"=>"AnunciosController", "method"=> "borrar_anuncio","publica" =>false),
    "modificar_anuncio" =>array("controller"=>"AnunciosController", "method"=> "modificar_anuncio","publica" =>false),
    "inicio" =>array("controller"=>"AnunciosController", "method"=> "inicio","publica" =>true),
    "personas" =>array("controller"=>"AnunciosController", "method"=> "personas","publica" =>false),
    "perfil" =>array("controller"=>"AnunciosController", "method"=> "perfil","publica" =>false),
    "tendencias" =>array("controller"=>"AnunciosController", "method"=> "tendencias","publica" =>false),
    "paraTi" =>array("controller"=>"AnunciosController", "method"=> "paraTi","publica" =>false),
    "loguearte" =>array("controller"=>"UsuariosController", "method"=> "loguearte","publica" =>true),
    "comprobar_email"=>array("controller"=>"UsuariosController", "method"=> "comprobar_email","publica" =>true),
    "borrar_anuncio_ajax" =>array("controller"=>"AnunciosController", "method"=> "borrar_ajax","publica" =>false),
    "insertar_anuncio_ajax" =>array("controller"=>"AnunciosController", "method"=> "anuncio_ajax","publica" =>false),
    "insertar_comentario_ajax" =>array("controller"=>"AnunciosController", "method"=> "comentario_ajax","publica" =>false),
    "insertarBorrarLike" =>array("controller"=>"AnunciosController", "method"=> "insertarBorrarLike","publica" =>false),
    "insertarBorrarSeguir" =>array("controller"=>"AnunciosController", "method"=> "insertarBorrarSeguir","publica" =>false),
    "sobreMi" =>array("controller"=>"UsuariosController", "method"=> "sobreMi","publica" =>true),
    "cambiarContra" =>array("controller"=>"UsuariosController", "method"=> "cambiarContra","publica" =>false),
    "unAnuncio" =>array("controller"=>"AnunciosController", "method"=> "unAnuncio","publica" =>false));

//PARSEO DE LA RUTA
if(!isset($_GET['action'])){
    $action= 'inicio';
}else{
    if(!isset($map[$_GET['action']])){
        header("Location: index.php?action=inicio");
        die();
    }else{
        $action= filter_var($_GET['action'], FILTER_SANITIZE_SPECIAL_CHARS);
    }  
}


//Cookie variable
if(!isset($_SESSION['idUsuario']) && isset($_COOKIE['uid'])){
    //OBTENEMOS EL USUARIO DE LA BD
    $uid= filter_var($_COOKIE['uid'],FILTER_SANITIZE_STRING);
    $UsuarioDAO = new UsuarioDAO(ConexionBD::conectar());
    $usuario=$UsuarioDAO->obtenerPorUid($uid);
        
    if(!$usuario){// Si no se encuentra el usuario
        setcookie("uid","",0);//Borramos la cookie
        header("Location: index.php");
    }else{
         //INICIAMOS SESIONES
        $_SESSION['email']=$usuario->getEmail();
        $_SESSION['idUsuario']=$usuario->getId();

        //RENOVAMOS COOKIE OTRA SEMANA
        setcookie("uid", $uid, time()+20*24*60*60, "/");
    }
}


//Session variable
if($map[$action]["publica"]==false && !isset($_SESSION["idUsuario"])){
    MensajeFlash::guardarMensaje("Debes identificarte");
    header("Location: index.php");
    die();
}

//EJECUTAMOS EL CONTROLADOR NECESARIO
$controlador = $map[$action]['controller'];
$method = $map[$action]['method'];

if(method_exists($controlador, $method)){
    $obj_controller= new $controlador();
    $obj_controller->$method();
}else{
    header('Status: 404 Not Found');
    echo "El método $method del controlador $controlador no existe";
}
