<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();
?>
<div class="tweets-container">
    <h1 class="tituloInicio">DESCUBRIR PERSONAS</h1>
    <br><br>
    <?php foreach ($usuarios as $usuario) : ?>
        <?php if ($usuario->getId() != $_SESSION['idUsuario']) : ?>
            <?php $siguiendo = false; ?>
            <?php foreach ($seguidores as $seguidor) : ?>
                <?php if ($seguidor->getIdSeguidor() == $_SESSION['idUsuario'] && $seguidor->getIdSiguiendo() == $usuario->getId()) : ?>
                    <?php $siguiendo = true; ?>
                    <?php break; ?>
                <?php endif; ?>
            <?php endforeach; ?>
            <div class="user-profile">
                <h4 class="user-name2"><a class="perfil" href="index.php?action=perfil&id=<?= $usuario->getId() ?>"><?= $usuario->getNombre() ?></a></h4>
                <div class="follow-button-container">
                    <?php if ($siguiendo): ?>
                        <div style="background-color: green" class="follow-button" data-id="<?= $usuario->getId() ?>">Siguiendo</div>
                    <?php else: ?>
                        <div style="background-color: #007bff" class="follow-button" data-id="<?= $usuario->getId() ?>">Seguir</div>
                    <?php endif; ?>    
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
<script>
// Obtén todos los elementos "Me gusta" y asígnales el controlador de eventos
function asignarControladoresEventos() {
  const followButtons = document.querySelectorAll('.follow-button');
    followButtons.forEach(button => {
      button.addEventListener('click', followButtonClick);
   });
}

// Llama a la función para asignar los controladores de eventos al cargar la página
asignarControladoresEventos();
function followButtonClick(event) {
  const followButton = event.target;
  const userId = followButton.getAttribute('data-id');
  const followerCountElement = document.getElementById(`follower-count`);
  
  // Realiza la solicitud AJAX
  fetch(`index.php?action=insertarBorrarSeguir&idUsuario=${userId}`)
    .then(response => response.json())
    .then(result => {
      if (result.success) {
        // Cambia el texto del botón según el resultado
        followButton.textContent = result.isFollowing ? 'Siguiendo' : 'Seguir';
        // Cambia el color de fondo del botón según el resultado
        followButton.style.backgroundColor = result.isFollowing ? 'green' : '#007bff';
      } else {
        // Maneja el caso de error
      }
    });
}
</script>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>

