<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();
?>
<div class="container2">
  <div class="publicacion">
    <div class="infoGusta">
        <div class="informacionP">
            <div class="titulo"><?= $anuncio->getTitulo() ?>-<a class="perfil" href="index.php?action=perfil&id=<?= $anuncio->getIdUsuario() ?>"><?= $usuario->getNombre() ?></a></div>
          <div class="descripcion"><?= $anuncio->getDescripcion() ?></div>
          <div class="fecha"><?= $anuncio->getFecha() ?></div>
        </div>
        <div class="me-gusta">
          <h4>Me gusta:</h4>
          <ul class="likes-list">
            <?php foreach ($likes as $like) : ?>
              <?php if ($like->getIdAnuncio() == $anuncio->getId()) : ?>
                <?php foreach ($usuarios as $usuarioLike) : ?>
                  <?php if ($usuarioLike->getId() == $like->getIdUsuarioDaLike()) : ?>
                    <li><?= $usuarioLike->getNombre() ?></li>
                  <?php endif; ?>
                <?php endforeach; ?>
              <?php endif; ?>
            <?php endforeach; ?>
          </ul>
        </div>
    </div>
        <div class="com" id="com">
            <h4>Comentarios:</h4>
            <div class="introducir-comentario">
             <textarea class="comentario-input" name="comentario" id="comentario" placeholder="Introduce un comentario"></textarea>
             <button class="comentario-boton" id="comentario-boton">
                <i class="fas fa-arrow-right"></i>
              </button>
            </div>
            <?php foreach ($comentarios as $comentario) : ?>
              <?php if ($anuncio->getId() == $comentario->getIdAnuncio()) : ?>
                <div class="comentario">
                  <?php foreach ($usuarios as $u) : ?>
                    <?php if ($u->getId() == $comentario->getIdUsuarioComenta()) : ?>
                      <div class="usuarioComentario"><?= $u->getNombre() ?></div>
                    <?php endif; ?>
                  <?php endforeach; ?>
                  <div class="contenidoComentario"><?= $comentario->getComentario() ?></div>
                </div>
              <?php endif; ?>
            <?php endforeach; ?>
      </div>
      <a href="index.php?action=inicio"><button class="atras">Volver</button></a>
  </div>
</div>
<script>
document.getElementById("comentario-boton").addEventListener("click", function(){
    const comentarioInput = document.getElementById('comentario');
    const comentario = comentarioInput.value.trim();
    
    if (comentario.length === 0) {
        // Si el comentario está vacío, mostrar una alerta o realizar la acción correspondiente
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'El comentario no puede estar vacío!'
        });
        return;
    }
    
    if (comentario.length > 250) {
        // Si el comentario excede los 300 caracteres, mostrar una alerta o realizar la acción correspondiente
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'El comentario no puede tener más de 300 caracteres!'
        });
        return;
    }
    
    Swal.fire({
        title: '¿Deseas añadir un comentario a esta publicación? No podra borrarlo',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí',
        cancelButtonText: 'No',
        customClass: {
            cancelButton: 'cancel-button-class'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Si se confirma, agregar el comentario
            const url = "index.php?action=insertar_comentario_ajax";
            let data = new FormData();
            var idAnuncio = <?= $anuncio->getId() ?>; // Asigna el valor de la variable PHP a la variable JavaScript
            data.append("comentario", document.getElementById('comentario').value);
            data.append("idAnuncio", idAnuncio);

            fetch(url, {method: "POST", body: data, credentials: 'same-origin' })
                .then(respuesta => respuesta.json())
                .then(json => {
                    //Código a ejecutar cuando reciba la respuesta
                    console.log(json);
                    //Crear capas
                    let capa_comentario = document.createElement("div");
                    let capa_usuario = document.createElement("div");
                    let capa_contenido = document.createElement("div");

                    //Asigno clases a las capas
                    capa_comentario.className = 'comentario';
                    capa_usuario.className = 'usuarioComentario';
                    capa_contenido.className = 'contenidoComentario';
                    //Rellen el contenido o html de cada capa
                    capa_usuario.innerHTML = json.nombreUsu;
                    capa_contenido.innerHTML = json.comentario.comentario;
                    //Añado las capas titulo, texto y fecha dentro de capa_mensaje
                    capa_comentario.append(capa_usuario);
                    capa_comentario.append(capa_contenido);

                    const commentContainer = document.querySelector('.introducir-comentario');
                    // Insertar el nuevo anuncio después de "comment-container"
                    commentContainer.insertAdjacentElement('afterend', capa_comentario);
                    // Limpiar el textarea después de enviar el comentario
                    comentarioInput.value = '';
                    Swal.fire({
                        icon: 'success',
                        title: 'Perfecto',
                        text: 'El comentario se introdujo correctamente!'
                    });
                })
                .catch(error => console.error(error));
        }
    });

}); //function
</script>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>

