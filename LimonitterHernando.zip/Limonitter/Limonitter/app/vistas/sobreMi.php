<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();
?>
<div class="tweets-container">
    <h1 class="tituloInicio">SOBRE MI</h1>
    <img src="web/img/sobreMi.jpeg" alt="Descripción de la imagen" class="imagen-sobre-mi">
</div>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>

