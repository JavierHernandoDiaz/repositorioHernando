<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();
?>
<section class="gradient-custom">
  <div class="container py-5">
    <div class="row d-flex justify-content-center align-items-center">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5 mx-auto my-5">
        <div class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">
            <form class="inicioL" action="index.php?action=login" id="login" method="post">
                <div class="mb-md-5 mt-md-4 pb-5">
                  <?php MensajeFlash::imprimirMensajes() ?>
                  <h2 class="fw-bold mb-2 text-uppercase">Inicia Sesión</h2>
                  <p class="text-white-50 mb-5">Por favor, introduce tu email y contraseña!</p>
                  <div class="form-outline form-white mb-4">
                    <label class="form-label" for="typeEmailX">Email</label>
                    <input type="email" name="email" id="typeEmailX" class="form-control form-control-lg form-control-sm" />                  
                  </div>
                  <div class="form-outline form-white mb-4">
                    <label class="form-label" for="typePasswordX">Contraseña</label>
                    <input type="password" name="password" id="typePasswordX" class="form-control form-control-lg form-control-sm" />                  
                  </div>
                  <button class="btn btn-outline-light btn-lg px-5" type="submit">Iniciar</button>
                </div>
            </form>
            <div>
              <p class="mb-0">A un no tienes una cuenta? <a href="index.php?action=registrar" class="text-white-50 fw-bold">Registrate</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>

