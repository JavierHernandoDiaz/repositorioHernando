<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();
?>
<?php
session_start();

// Verificar si hay un mensaje en la variable de sesión
if (isset($_SESSION['contraMal'])) {
  // Mostrar el mensaje en la página
  echo "<script>Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'La contraseña actual no coincide.!'
    });</script>";

  // Eliminar el mensaje de la variable de sesión para que no se muestre nuevamente
  unset($_SESSION['contraMal']);
}
if (isset($_SESSION['contraBien'])) {
  echo "<script>Swal.fire({
          icon: 'success',
          title: 'Perfecto',
          text: 'La contraseña se cambio correctamente.!'
    });</script>";

  unset($_SESSION['contraBien']);
}
?>
<div class="tweets-container">
    <h1 class="tituloInicio">LIMONITTERS WORLD</h1>
  <?php foreach ($anuncios as $a): ?>
    <?php 
        $contadorComentarios = 0; // Variable para contar los comentarios
        foreach ($comentarios as $c) {
            if ($c->getIdAnuncio() == $a->getId()) {
                $contadorComentarios++; // Aumentar el contador de comentarios
            }
        }
        $contadorLikes = 0; // Variable para contar los likes
        $usuarioDioLike = false; // Variable para verificar si el usuario dio like
        foreach ($likes as $l) {
            if ($l->getIdAnuncio() == $a->getId()) {
                $contadorLikes++; // Aumentar el contador de likes
                if ($l->getIdUsuarioDaLike() == $idUsuario) {
                    $usuarioDioLike = true; // El usuario dio like
                }
            }
        }
        $nombreUsuario = ""; // Variable para almacenar el nombre de usuario correspondiente
        foreach ($usuarios as $u) {
            if ($a->getIdUsuario() == $u->getId()) {
                $nombreUsuario = $u->getNombre();
                break; // Se encontró el nombre de usuario, se puede salir del bucle
            }
        }
        ?>
    <div class="tweet-container">
        <div class="tweet-header">
            <h4 class="tweet-title"><?= $a->getTitulo() ?> - <a class="perfil" href="index.php?action=perfil&id=<?= $a->getIdUsuario() ?>"><?= $nombreUsuario ?></a></h4>
        </div>
        <div class="tweet-body">
            <p class="tweet-description"><?= $a->getDescripcion() ?></p>
        </div>
        <div class="tweet-info">
            <div class="tweet-icons">
                <?php if ($idUsuario): ?>
                    <?php if ($usuarioDioLike): ?>
                        <i class="fas fa-heart like-button liked" data-id="<?= $a->getId() ?>"></i>
                    <?php else: ?>
                        <i class="fas fa-heart like-button" data-id="<?= $a->getId() ?>"></i>
                    <?php endif; ?>
                <?php else: ?>
                    <i class="fas fa-heart like-button" data-id="<?= $a->getId() ?>"></i>
                <?php endif; ?>
                <span class="like-count" id="like-count-<?= $a->getId() ?>"><?= $contadorLikes ?></span><span class="gusta">&nbsp;Me gusta</span>
                <a class="links" href="index.php?action=unAnuncio&id=<?= $a->getId() ?>"><i class="fas fa-comment"></i></a><?= $contadorComentarios ?> Comentarios
            </div>
            <span class="tweet-date"><?= $a->getFecha() ?></span>
        </div>
    </div>
  <?php endforeach; ?>
</div>
<script>
// Obtén todos los elementos "Me gusta" y asígnales el controlador de eventos
const likeButtons = document.querySelectorAll('.like-button');
likeButtons.forEach(button => {
button.addEventListener('click', likeButtonClick);
});

// Controlador de eventos para el clic en el botón "Me gusta"
// Controlador de eventos para el clic en el botón "Me gusta"
// Controlador de eventos para el clic en el botón "Me gusta"
function likeButtonClick(event) {
  const likeButton = event.target;
  const idAnuncio = likeButton.getAttribute('data-id');
  const likeCountElement = document.getElementById(`like-count-${idAnuncio}`);
  
  // Realiza la solicitud AJAX
  fetch(`index.php?action=insertarBorrarLike&idAnuncio=${idAnuncio}`)
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            // Cambia el color del corazón al dar like
            likeButton.classList.toggle('liked');
            
            // Actualiza el contador de likes si el contador está definido en la respuesta
            if (result.contadorLikes !== undefined) {
                likeCountElement.textContent = result.contadorLikes;
            }
        } else {
            // Maneja el caso de error
        }
    })
    .catch(error => {
        // Maneja el error de la solicitud de insertar o borrar like
    });
    }
</script>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>

