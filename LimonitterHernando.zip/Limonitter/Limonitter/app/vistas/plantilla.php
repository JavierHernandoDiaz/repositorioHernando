<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inicio</title>
    <script src="https://kit.fontawesome.com/2aadf0fc03.js" crossorigin="anonymous"></script>
    <link rel="icon" href="web/img/logo.jpg" type="image/jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous"><!-- comment -->
    <link rel="stylesheet" href="web/css/estilos.css"/>
    <script src="https://code.jquery.com/jquery-3.6.1.slim.js" integrity="sha256-tXm+sa1uzsbFnbXt8GJqsgi2Tw+m4BLGDof6eUPjbtk=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <div class="d-flex align-items-center">
                <a class="navbar-brand" href="index.php?action=inicio">LIMONITTER
                <img src="web/img/logo.jpg" alt="Logo" class="logo-image"></a>
            </div>
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
            <div class="offcanvas-header">
                <?php if (isset($_SESSION['email'])): ?>
                <div class="iniciado">
                    <strong><?= $_SESSION['email'] ?></strong><br>
                    <a class="logout-button" href="index.php?action=logout">cerrar sesión</a>
                </div>
                <?php else: ?>
                    <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel"><a class="navbar-brand" href="index.php?action=loguearte">Inicia sesión</a></h5>
                <?php endif; ?>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
              <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="index.php?action=inicio">Inicio</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php?action=sobreMi">Sobre mi</a>
                </li>
                 <?php if (isset($_SESSION['email'])): ?>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Apartados
                  </a>
                  <ul class="dropdown-menu dropdown-menu-dark">                 
                    <li>
                    <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="index.php?action=paraTi">Para ti</a></li>
                    <li><a class="dropdown-item" href="index.php?action=perfil&id=<?=$_SESSION['idUsuario']?>">Mis Limonitters</a></li>
                    <li><a class="dropdown-item" href="index.php?action=tendencias">Tendencias</a></li>
                    <li><a class="dropdown-item" href="index.php?action=personas">Descubrir Personas</a></li>
                    <?php endif; ?>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
    </nav>  
    <main class="container">
    <!--AQUI ESTA LA VISTA WEY-->
    <?php 
    print $vista;
    ?>
    
    <!--AQUI TERMINA LA VISTA WEY-->
    </main>
     
    </body>
</html>
