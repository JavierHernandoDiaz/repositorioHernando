<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();
?>
<div id="listado_anuncios">
    <?php foreach ($anuncios as $a): ?>
        <?php if (isset($_SESSION['email']) && $_SESSION['idUsuario']== $a->getIdUsuario()): ?>
            <div class="anuncio container">
                <div class="titulo"><?= $a->getTitulo() ?></div><br>
                <b>Descripión:</b> <div class="descripcion"><?=($a->getDescripcion()) ?></div><br>
                <b>Precio:</b> <div class="precio"><?= $a->getPrecio() ?>€</div>
                <div class = "borrar_ajax" data-id="<?= $a->getId() ?>"><i class = "fa-solid fa-trash" ></i></div>
                <div class = "editar"><a href = "index.php?action=modificar_anuncio&id=<?= $a->getId() ?>"><i class = "fa-solid fa-pen-to-square" ></i></a></div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>

<br><br>
<!-- Formulario para añadir mensajes por AJAX -->
<br><br>
<div>
<b>Título: </b><input type="text" name="titulo" id="titulo" placeholder="Título del anuncio" class="form-control">
<textarea name="descripcion" id="descripcion" placeholder="Descripcion del anuncio" class="form-control"></textarea>
<br><input type="button" id="botonInsertarAnuncio" value="Insertar Anuncio" class="btn btn-primary">
</div>
<!-- Enlace para añadir mensajes SIN AJAX -->
<br><br>
        
<!--Insertar mensaje SIN AJAX-->
<?php if (isset($_SESSION['email'])): ?>
    <a class="bIn" href="index.php?action=insertar_anuncio"><button class="bIn">Nuevo Anuncio</button></a>
<?php endif; ?>

<script>
        //Añadimos un manejador de evento para el botón insertar    
            document.getElementById("botonInsertarAnuncio").addEventListener("click", function(){
                const url="index.php?action=insertar_anuncio_ajax";
                let data = new FormData();
                data.append("titulo", document.getElementById('titulo').value);
                data.append("descripcion", document.getElementById('descripcion').value);
                
                fetch(url,{method:"POST", body: data, credentials: 'same-origin' })
                .then( respuesta => respuesta.json())
                .then( json => { 
                    //Código a ejecutar cuando reciba la respuesta
                    console.log(json);
                    //Crear capas
                    let capa_anuncio = document.createElement("div");
                    let capa_titulo = document.createElement("div");
                    let capa_descripcion = document.createElement("div");
                    //Asigno clases a las capas
                    capa_anuncio.className='anuncio container';
                    capa_titulo.className = 'titulo';
                    capa_descripcion.className = 'descripcion';
                    //Rellen el contenido o html de cada capa
                    capa_titulo.innerHTML = json.anuncio.titulo;
                    capa_descripcion.innerHTML = json.anuncio.descripcion;
                    //Añado las capas titulo, texto y fecha dentro de capa_mensaje
                    capa_anuncio.append(capa_titulo);
                    capa_anuncio.append(capa_descripcion);
                    
                    //Añado la papelera de ajax
                    let capa_papelera_ajax = document.createElement("div");
                    capa_papelera_ajax.className ="borrar_ajax";
                    capa_papelera_ajax.setAttribute("data-id",json.anuncio.id);
                    let papelera_icono = document.createElement('i');
                    papelera_icono.className="fa-solid fa-trash";
                    capa_papelera_ajax.append(papelera_icono);
                    capa_anuncio.append(capa_papelera_ajax);
                    //Añado la capa_mensaje al final de la capa listado_mensajes
                    document.getElementById('listado_anuncios').appendChild(capa_anuncio);
                    //Añado la funcionalidad a la papelera
                    capa_papelera_ajax.addEventListener("click", borrar_anuncio_ajax);
                })
                .catch( error => console.error(error));
                
            }); //function
     
    
        let enlaces_borrar = document.getElementsByClassName("borrar_ajax");
        for(var i=0; i<enlaces_borrar.length;i++){
            enlaces_borrar[i].addEventListener("click", borrar_anuncio_ajax);
        }
        function borrar_anuncio_ajax(){
            let url="index.php?action=borrar_anuncio_ajax&id="+this.getAttribute("data-id");//this hace referencia al elemento al que hicimos click
            fetch(url)
            .then(respuesta => respuesta.json())
            .then((json) =>{
                //Borrar la capa del mensaje               
                if(json.borrado){
                    this.parentElement.remove();
                }
            })
            .catch((error)=> {
                console.error("Error en : "+error);
            });
        }
</script>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>

