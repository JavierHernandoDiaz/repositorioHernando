<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();

$nombre = "";
$email = "";
$password="";
$password2="";
// Verificar si existen variables de sesión y asignar los valores correspondientes
if (isset($_SESSION['nombre'])) {
    $nombre = $_SESSION['nombre'];
}
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
}
if (isset($_SESSION['password'])) {
    $password = $_SESSION['password'];
}
if (isset($_SESSION['password2'])) {
    $password2 = $_SESSION['password2'];
}
?>
<section>
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card card2" style="border-radius: 15px;">
            <div class="card-body p-5">
                <div class="header-container">
                    <br><br>
                    <?php MensajeFlash::imprimirMensajes() ?>
                    <h2 class="text-uppercase text-center mb-5">Registrate</h2>
                </div>
              <form action="index.php?action=registrar" method="post">
                <div class="form-outline mb-4">
                  <label class="form-label" for="form3Example1cg">Nombre</label>
                  <input type="text" name="nombre" id="form3Example1cg" class="form-control form-control-lg" value="<?=$nombre?>"/>    
                </div>
                <div class="form-outline mb-4">
                  <label class="form-label" for="form3Example3cg">Email</label><span id="comEm"></span>
                  <input id="email" type="email" name="email" id="form3Example3cg" class="form-control form-control-lg" value="<?=$email?>"/>
                </div>
                <div class="form-outline mb-4">
                  <label class="form-label" for="form3Example4cg">Contraseña</label>
                  <input type="password" name="password" id="form3Example4cg" class="form-control form-control-lg" value="<?=$password?>"/>                 
                </div>
                <div class="form-outline mb-4">
                  <label class="form-label" for="form3Example4cdg">Repite la contraseña</label>
                  <input type="password" name="password2" id="form3Example4cdg" class="form-control form-control-lg" value="<?=$password2?>"/>               
                </div>

                <div class="d-flex justify-content-center">
                  <button type="submit" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">Registrar</button>
                </div>

                <p class="text-center text-muted mt-5 mb-0">Ya tienes una cuenta? <a href="index.php?action=loguearte" class="fw-bold text-body"><u>Inicia sesión ahora</u></a></p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script type="text/javascript">
    document.getElementById('email').addEventListener('change', function(){
        document.getElementById('comEm').innerHTML= '<i class="fas fa-cog fa-spin"></i>';
        let data = new FormData();
        data.append("email",document.getElementById("email").value);
        let url="index.php?action=comprobar_email";
        let init={
        method: 'POST',
        body: data
        };//Final init
        
        fetch(url,init)
        .then(function(respuesta){
            return respuesta.json();
        })
        .then(function(json){
            if(json.repetido){
                document.getElementById('comEm').innerHTML= '<i id="email_cruz" class="fas fa-times-circle"></i>';
            }else{
                document.getElementById('comEm').innerHTML= '<i id="check" class="fas fa-check-circle"></i>';
            }
        })
        .catch(function(error){
            console.error(error);
        });//Final fetch
    });//Final metodo document.getElementById
</script>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>
