<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
//EL CODIGO HTML NO SE ENVIA AL CLIENTE, SE GUARDA EN MEMORIA
ob_start();
?>
<?php
$contadorSegui = 0; // Variable para contar los seguidores
$usuarioDioSeguir = false; // Variable para verificar si el usuario dio seguir
foreach ($seguidores as $s) {
    if ($s->getIdSiguiendo() == $nombreU->getId()) {
        $contadorSegui++;
        if ($s->getIdSeguidor() == $_SESSION['idUsuario']) {
            $usuarioDioSeguir = true; // El usuario dio seguir
        }
    }
}
?>
<div class="tweets-container">
    <div class="user-profile">
        <h1 class="user-name"><?= $nombreU->getNombre()?></h1>
        <?php if ($_SESSION['idUsuario']!=$nombreU->getId()): ?>
            <?php if ($usuarioDioSeguir): ?>
                <div style="background-color: green" class="follow-button" data-id="<?= $nombreU->getId() ?>" >Siguiendo</div>
            <?php else: ?>
                <div style="background-color: #007bff" class="follow-button" data-id="<?= $nombreU->getId() ?>" >Seguir</div>
            <?php endif; ?>    
        <?php endif; ?>
    </div>
    <div class="contSeguidores">
        <h4 id="follower-count">Seguidores: <?= $contadorSegui ?></h4>
    </div>
    <?php if ($idPerfil==$_SESSION['idUsuario']): ?>
        <!-- Botón para abrir la ventana modal -->
        <button id="open-modal-btn">Cambiar Contraseña</button>

        <!-- Ventana modal -->
        <div id="modal" class="modal">
          <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Cambiar Contraseña</h2>
            <form id="password-form" onsubmit="return validarFormulario()" action="index.php?action=cambiarContra" method="POST">
            <label for="contraseñaActual">Contraseña actual:</label>
            <input type="password" id="contraseñaActual" name="contraseñaActual">

            <label for="nuevaContraseña">Nueva contraseña:</label>
            <input type="password" id="nuevaContraseña" name="nuevaContraseña">

            <label for="confirmarContraseña">Confirmar contraseña:</label>
            <input type="password" id="confirmarContraseña" name="confirmarContraseña">

            <button class="guardar" type="submit">Cambiar contraseña</button>
            </form>
          </div>
        </div>
    <?php endif; ?>
    <br>
    <?php if ($idPerfil==$_SESSION['idUsuario']): ?>
    <div class="comment-container">
        <div class="comment-header">
        </div>
        <div class="comment-body">
          <div class="form-group">
            <label for="titulo" class="comment-label">Título:</label>
            <input type="text" name="titulo" id="titulo" placeholder="Título de la publicación" class="comment-input">
          </div>
          <div class="form-group">
            <label for="descripcion" class="comment-label">Descripción:</label>
            <textarea name="descripcion" id="descripcion" placeholder="Descripción de la publicación" class="comment-textarea"></textarea>
          </div><br>
          <div class="form-group">
            <input type="button" id="botonInsertarAnuncio" value="Crear Publicación" class="comment-button">
          </div>
        </div>
    </div>
    <?php endif; ?>
  <?php foreach ($anuncios as $a): ?>
    <?php 
        $contadorComentarios = 0; // Variable para contar los comentarios
        foreach ($comentarios as $c) {
            if ($c->getIdAnuncio() == $a->getId()) {
                $contadorComentarios++; // Aumentar el contador de comentarios
            }
        }
        $contadorLikes = 0; // Variable para contar los likes
        $usuarioDioLike = false; // Variable para verificar si el usuario dio like
        foreach ($likes as $l) {
            if ($l->getIdAnuncio() == $a->getId()) {
                $contadorLikes++; // Aumentar el contador de likes
                if ($l->getIdUsuarioDaLike() == $idUsuario) {
                    $usuarioDioLike = true; // El usuario dio like
                }
            }
        }
        $nombreUsuario = ""; // Variable para almacenar el nombre de usuario correspondiente
        foreach ($usuarios as $u) {
            if ($a->getIdUsuario() == $u->getId()) {
                $nombreUsuario = $u->getNombre();
                break; // Se encontró el nombre de usuario, se puede salir del bucle
            }
        }
        ?>
    <div class="tweet-container">
        <?php if ($a->getIdUsuario()==$_SESSION['idUsuario']): ?>
            <div class = "borrar_ajax" data-id="<?= $a->getId() ?>"><i class = "fa-solid fa-trash" ></i></div>
        <?php endif; ?>
        <div class="tweet-header">
            <h4 class="tweet-title"><?= $a->getTitulo() ?> - <a class="perfil" href="index.php?action=perfil&id=<?= $a->getIdUsuario() ?>"><?= $nombreUsuario ?></a></h4>          
        </div>
        <div class="tweet-body">
            <p class="tweet-description"><?= $a->getDescripcion() ?></p>
        </div>
        <div class="tweet-info">
            <div class="tweet-icons">
                <?php if ($idUsuario): ?>
                    <?php if ($usuarioDioLike): ?>
                        <i class="fas fa-heart like-button liked" data-id="<?= $a->getId() ?>"></i>
                    <?php else: ?>
                        <i class="fas fa-heart like-button" data-id="<?= $a->getId() ?>"></i>
                    <?php endif; ?>
                <?php else: ?>
                    <i class="fas fa-heart like-button" data-id="<?= $a->getId() ?>"></i>
                <?php endif; ?>
                <span class="like-count" id="like-count-<?= $a->getId() ?>"><?= $contadorLikes ?></span><span class="gusta">&nbsp;Me gusta</span>
                <a class="links" href="index.php?action=unAnuncio&id=<?= $a->getId() ?>"><i class="fas fa-comment"></i></a><?= $contadorComentarios ?> Comentarios
            </div>
            <span class="tweet-date"><?= $a->getFecha() ?></span>
        </div>
    </div>
  <?php endforeach; ?>
</div>
<script>
function validarFormulario() {
  var contraseñaActual = document.getElementById('contraseñaActual').value;
  var nuevaContraseña = document.getElementById('nuevaContraseña').value;
  var confirmarContraseña = document.getElementById('confirmarContraseña').value;
  
  if (contraseñaActual === '' || nuevaContraseña === '' || confirmarContraseña === '') {
    Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Por favor, completa todos los campos.!'
    });
    return false;
  }
  
  if (nuevaContraseña !== confirmarContraseña) {
    Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'La nueva contraseña y la confirmación de contraseña no coinciden.!'
    });
    return false;
  }
  
  return true;
}
// Obtén los elementos necesarios
const openModalButton = document.getElementById('open-modal-btn');
const modal = document.getElementById('modal');
const closeButton = document.getElementsByClassName('close')[0];

if(openModalButton){
// Abre la ventana modal
openModalButton.addEventListener('click', function() {
  modal.style.display = 'block';
});

// Cierra la ventana modal cuando se hace clic en la "x"
closeButton.addEventListener('click', function() {
  modal.style.display = 'none';
});

// Cierra la ventana modal cuando se hace clic fuera del contenido
window.addEventListener('click', function(event) {
  if (event.target == modal) {
    modal.style.display = 'none';
  }
});
}
// Añadimos un manejador de evento para el botón insertar
var botonInsertarAnuncio = document.getElementById("botonInsertarAnuncio");
if (botonInsertarAnuncio) {
document.getElementById("botonInsertarAnuncio").addEventListener("click", function() {
    const comentarioInput = document.getElementById('descripcion');
    const comentario = comentarioInput.value.trim();
    const tituloInput = document.getElementById('titulo');
    const titulo = tituloInput.value.trim();

    if (comentario.length === 0 || titulo.length === 0) {
        // Si el comentario está vacío, mostrar una alerta o realizar la acción correspondiente
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'La descripcion y el titulo no pueden estar vacíos!'
        });
        return;
    }

    if (comentario.length > 190 || titulo.length > 50) {
        // Si el comentario excede los 300 caracteres, mostrar una alerta o realizar la acción correspondiente
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'El comentario no puede tener más de 190 caracteres y el titulo no puede tener más de 50 caracteres!'
        });
        return;
    }
  const url = "index.php?action=insertar_anuncio_ajax";
  let data = new FormData();
  data.append("titulo", document.getElementById('titulo').value);
  data.append("descripcion", document.getElementById('descripcion').value);

  fetch(url, { method: "POST", body: data, credentials: 'same-origin' })
    .then(respuesta => respuesta.json())
    .then(json => {
      // Código a ejecutar cuando reciba la respuesta
      console.log(json);

      // Crear capa principal del anuncio
      let capa_anuncio = document.createElement("div");
      capa_anuncio.className = 'tweet-container';
      
      // Agregar el elemento de borrado del anuncio (si corresponde)
        let capa_borrar = document.createElement("div");
        capa_borrar.className = 'borrar_ajax';
        capa_borrar.setAttribute("data-id", json.anuncio.id);
        capa_borrar.innerHTML = '<i class="fa-solid fa-trash"></i>';
        capa_borrar.addEventListener("click", borrar_anuncio_ajax);
        capa_anuncio.appendChild(capa_borrar);
      
      // Crear capa del encabezado
      let capa_encabezado = document.createElement("div");
      capa_encabezado.className = 'tweet-header';

      // Crear título y enlace del usuario
      let titulo_usuario = document.createElement("h4");
      titulo_usuario.className = 'tweet-title';
      titulo_usuario.innerHTML = json.anuncio.titulo + ' - <a class="perfil" href="index.php?action=perfil&id=' + json.anuncio.idUsuario + '">' + json.nombreU + '</a>';

      // Añadir título y enlace del usuario a la capa del encabezado
      capa_encabezado.appendChild(titulo_usuario);

      // Crear capa del cuerpo
      let capa_cuerpo = document.createElement("div");
      capa_cuerpo.className = 'tweet-body';

      // Crear descripción del anuncio
      let descripcion_anuncio = document.createElement("p");
      descripcion_anuncio.className = 'tweet-description';
      descripcion_anuncio.innerHTML = json.anuncio.descripcion;

      // Añadir descripción del anuncio a la capa del cuerpo
      capa_cuerpo.appendChild(descripcion_anuncio);

      // Crear capa de información
      let capa_info = document.createElement("div");
      capa_info.className = 'tweet-info';

      // Crear iconos y contador de likes
      let iconos_likes = document.createElement("div");
      iconos_likes.className = 'tweet-icons';

      // Verificar si el usuario dio like y agregar el estilo correspondiente
      let like_icon = document.createElement("i");
      like_icon.className = 'fas fa-heart like-button';
      like_icon.setAttribute("data-id", json.anuncio.id);
      if (json.anuncio.usuarioDioLike) {
        like_icon.classList.add('liked');
      }

      // Crear contador de likes
      let contador_likes = document.createElement("span");
      contador_likes.className = 'like-count';
      contador_likes.id = 'like-count-' + json.anuncio.id;
      contador_likes.innerHTML = '0';

      // Crear texto "Me gusta"
      let gusta_texto = document.createElement("span");
      gusta_texto.className = 'gusta';
      gusta_texto.innerHTML = '&nbsp;Me gusta';

      // Crear enlace a los comentarios
      let enlace_comentarios = document.createElement("a");
      enlace_comentarios.className = 'links';
      enlace_comentarios.href = 'index.php?action=unAnuncio&id=' + json.anuncio.id;
      enlace_comentarios.innerHTML = '<i class="fas fa-comment"></i>0 Comentarios';

      // Agregar los elementos al icono de likes
      iconos_likes.appendChild(like_icon);
      iconos_likes.appendChild(contador_likes);
      iconos_likes.appendChild(gusta_texto);
      iconos_likes.appendChild(enlace_comentarios);

      // Crear fecha del anuncio
      let fecha_anuncio = document.createElement("span");
      fecha_anuncio.className = 'tweet-date';
      fecha_anuncio.innerHTML = json.anuncio.fecha;

      // Añadir los elementos a la capa de información
      capa_info.appendChild(iconos_likes);
      capa_info.appendChild(fecha_anuncio);

      // Añadir las capas al anuncio principal
      capa_anuncio.appendChild(capa_encabezado);
      capa_anuncio.appendChild(capa_cuerpo);
      capa_anuncio.appendChild(capa_info);

      // Obtén una referencia al elemento "comment-container"
      const commentContainer = document.querySelector('.comment-container');

      // Insertar el nuevo anuncio después de "comment-container"
      commentContainer.insertAdjacentElement('afterend', capa_anuncio);
      // Asignar los controladores de eventos a los nuevos elementos
      asignarControladoresEventos();
      comentarioInput.value = ''
      tituloInput.value = ''
      Swal.fire({
            icon: 'success',
            title: 'Perfecto',
            text: 'Añadiste una nueva publicación!'
        });
    })
    .catch(error => console.error(error));
});
}
// Obtén todos los elementos "Me gusta" y asígnales el controlador de eventos
function asignarControladoresEventos() {
  const likeButtons = document.querySelectorAll('.like-button');
  likeButtons.forEach(button => {
    button.addEventListener('click', likeButtonClick);
  });
  const followButtons = document.querySelectorAll('.follow-button');
    followButtons.forEach(button => {
      button.addEventListener('click', followButtonClick);
   });
}

// Llama a la función para asignar los controladores de eventos al cargar la página
asignarControladoresEventos();

// Controlador de eventos para el clic en el botón "Me gusta"
function likeButtonClick(event) {
  const likeButton = event.target;
  const idAnuncio = likeButton.getAttribute('data-id');
  const likeCountElement = document.getElementById(`like-count-${idAnuncio}`);
  
  // Realiza la solicitud AJAX
  fetch(`index.php?action=insertarBorrarLike&idAnuncio=${idAnuncio}`)
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            // Cambia el color del corazón al dar like
            likeButton.classList.toggle('liked');
            
            // Actualiza el contador de likes si el contador está definido en la respuesta
            if (result.contadorLikes !== undefined) {
                likeCountElement.textContent = result.contadorLikes;
            }
        } else {
            // Maneja el caso de error
}
    })
    .catch(error => {
        // Maneja el error de la solicitud de insertar o borrar like
    });
    }
let enlaces_borrar = document.getElementsByClassName("borrar_ajax");
for(var i=0; i<enlaces_borrar.length;i++){
    enlaces_borrar[i].addEventListener("click", borrar_anuncio_ajax);
}
function borrar_anuncio_ajax(){
    let url="index.php?action=borrar_anuncio_ajax&id="+this.getAttribute("data-id");//this hace referencia al elemento al que hicimos click
    fetch(url)
    .then(respuesta => respuesta.json())
    .then((json) =>{
        //Borrar la capa del mensaje               
        if(json.borrado){
            this.parentElement.remove();
            Swal.fire({
            icon: 'success',
            title: 'Completado',
            text: 'Borraste la publicación!'
            });
        }
    })
    .catch((error)=> {
        console.error("Error en : "+error);
    });
}
function followButtonClick(event) {
  const followButton = event.target;
  const userId = followButton.getAttribute('data-id');
  const followerCountElement = document.getElementById(`follower-count`);
  
  // Realiza la solicitud AJAX
  fetch(`index.php?action=insertarBorrarSeguir&idUsuario=${userId}`)
    .then(response => response.json())
    .then(result => {
      if (result.success) {
        // Cambia el texto del botón según el resultado
        followButton.textContent = result.isFollowing ? 'Siguiendo' : 'Seguir';
        // Cambia el color de fondo del botón según el resultado
        followButton.style.backgroundColor = result.isFollowing ? 'green' : '#007bff';

        // Actualiza el contador de seguidores si está definido en la respuesta
        if (result.followerCount !== undefined) {
          followerCountElement.textContent = "Seguidores: "+result.followerCount;
        }
      } else {
        // Maneja el caso de error
      }
    });
}
</script>
<?php
//Guarda todo el html en $vista
$vista=ob_get_clean();
require 'app/vistas/plantilla.php'
?>

