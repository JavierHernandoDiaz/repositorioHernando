<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class MensajeFlash {
    static function guardarMensaje($mensaje) {
        self::borrarMensajes(); // Eliminar mensajes flash existentes
        $_SESSION['mensajesFlash'][] = $mensaje;
    }

    static function imprimirMensajes() {
        if (isset($_SESSION['mensajesFlash'])) {
            foreach ($_SESSION['mensajesFlash'] as $mensaje) {
                print '<h4 class="flash-message">' . $mensaje . '</h4>';
            }
            self::borrarMensajes(); // Eliminar mensajes flash después de imprimirlos
        }
    }

    static function borrarMensajes() {
        unset($_SESSION['mensajesFlash']);
    }
}
