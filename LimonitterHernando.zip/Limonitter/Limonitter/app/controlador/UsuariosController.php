<?php
/*
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class UsuariosController {
    function loguearte(){    
        //Incluimos la vista
        require 'app/vistas/loguearte.php';
    }
    function sobreMi(){    
        //Incluimos la vista
        require 'app/vistas/sobreMi.php';
    }
    function registrar(){
    $email = "";
    $password = "";
    $nombre = "";

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $usuario = new Usuario();
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);
        $password2 = filter_var($_POST['password2'], FILTER_SANITIZE_STRING);
        $nombre = filter_var($_POST['nombre'], FILTER_SANITIZE_STRING);
        $_SESSION['nombre'] = $nombre;
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;
        $_SESSION['password2'] = $password2;
        $error = false;

        // Validar que los campos no estén vacíos
        if (empty($email) || empty($password) || empty($password2) || empty($nombre)) {
            MensajeFlash::guardarMensaje("Todos los campos son obligatorios");
            $error = true;
        }

        // Validar la longitud de los campos
        if (strlen($password) > 100) {
            MensajeFlash::guardarMensaje("La contraseña no puede tener más de 100 caracteres");
            $error = true;
        }

        if (strlen($email) > 60) {
            MensajeFlash::guardarMensaje("El email no puede tener más de 60 caracteres");
            $error = true;
        }

        if (strlen($nombre) > 20) {
            MensajeFlash::guardarMensaje("El nombre no puede tener más de 20 caracteres");
            $error = true;
        }
        
        //Comprobamos si existe un usuario con el mismo email
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        if ($usuarioDAO->obtenerUsuarioEmail($email)) {
            //Ya existe un usuario con el mismo email
            MensajeFlash::guardarMensaje("Email repetido");
            $error = true;
        }
        if($password!=$password2){
            MensajeFlash::guardarMensaje("Las contraseñas no son iguales");
            $error = true;
        }

        if (!$error) {     
            unset($_SESSION['nombre']);
            unset($_SESSION['email']);
            unset($_SESSION['password']);
            unset($_SESSION['password2']);
            $passwordCodificado = password_hash($password, PASSWORD_BCRYPT);
            $usuario->setEmail($email);
            $usuario->setNombre($nombre);
            $usuario->setPassword($passwordCodificado);
            $usuario->setUid("");
            $usuarioDAO->insertar($usuario);

            header('Location: index.php');
            die();
        }else{
            require 'app/vistas/registrar.php';
        }
        }else{
            require 'app/vistas/registrar.php';
        }
    }
    function cambiarContra(){
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $currentPassword = filter_var($_POST['contraseñaActual'], FILTER_SANITIZE_STRING);
        $newPassword = $_POST['nuevaContraseña'];
        $confirmPassword = $_POST['confirmarContraseña'];

        // Verificar si las contraseñas nuevas coinciden
        if ($newPassword !== $confirmPassword) {
          header("Location: index.php");
          die();
        }

        // Verificar si la contraseña actual es correcta
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $usuario = $usuarioDAO->obtenerUsu($_SESSION['idUsuario']);

        $currentPasswordCorrect = password_verify($currentPassword, $usuario->getPassword());
        if (!$currentPasswordCorrect) {
          $_SESSION['contraMal']="mal";
          header("Location: index.php");
          die();
        }

        // Generar el nuevo hash de la contraseña
        $newPasswordHash = password_hash($newPassword, PASSWORD_BCRYPT);

        $usuarioDAO->actualizarContraseña($usuario->getId(), $newPasswordHash);
        $_SESSION['contraBien']="bien";
        header("Location: index.php");
      }
    }
    function login(){
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $passwordFormulario = filter_var($_POST['password'], FILTER_SANITIZE_STRING);
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $usuario = $usuarioDAO->obtenerUsuarioEmail($email);
        if(!$usuario){  //El usuario con ese email no existe.
            MensajeFlash::guardarMensaje("El usuario o la contraseña no son válidos");
            require 'app/vistas/loguearte.php';
            die();
        }
        //Usuario con ese email si existe
        elseif( !password_verify($passwordFormulario, $usuario->getPassword())){   //Login incorrecto
            MensajeFlash::guardarMensaje("El usuario o la contraseña no son válidos");
            require 'app/vistas/loguearte.php';
            die();     
        }
        else{
        //Usuario y contraseña son correctos. 
        //Iniciamos sesión
        $_SESSION['email']=$usuario->getEmail();
        $_SESSION['idUsuario']=$usuario->getId();
        
        //Guardamos cookie para recordar al cerrar navegador
        $uid = sha1(time()+rand()).md5(time());
        $usuario->setUid($uid);
        $usuarioDAO->actualizar($usuario);
        setcookie("uid", $uid, time()+20*24*60*60, "/");
        
        header("Location: index.php");
        die();
        }
    }
    function logout(){
        unset($_SESSION['idUsuario']);
        unset($_SESSION['email']);
        setcookie("uid", '', time() - 3600, "/");
        header("Location: index.php");
    }
    
    function comprobar_email(){
        header("Content-type: apllication/json; charset=utf-8");//Con esto le decimos al navegador que es una respuesta json
        //Si no se ha enviado el email por post pues pasa esto wey
        if(!isset($_POST['email'])){
            print json_encode(["error" => "falta parámetro email"]);
            die();
        }
        $email = filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar()); 
        if($usuarioDAO->obtenerUsuarioEmail($email)){//Si devuelve true
            print json_encode(array("repetido"=>true)); //codifica cualquier array de php a json
        }else{
            print json_encode(array("repetido"=>false));
        }
        sleep(1);
    }
}
