<?php
/*
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */

class AnunciosController {
    function inicio(){
        if(isset($_SESSION['idUsuario'])){
            $idUsuario=$_SESSION['idUsuario'];
        }else{
            $idUsuario=0;
        }       
        $anuncioDAO = new AnuncioDAO(ConexionBD::conectar());
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $comentarioDAO = new ComentarioDAO(ConexionBD::conectar());
        $likesDAO = new LikesDAO(ConexionBD::conectar());
        //Obtengo todos los mensajes de la BD
        $anuncios = $anuncioDAO->obtenerTodos();
        $comentarios = $comentarioDAO->obtenerTodos();
        $usuarios = $usuarioDAO->obtenerUsuarios();
        $likes = $likesDAO->obtenerTodos();
        
        //Incluimos la vista
        require 'app/vistas/inicio.php';
    }
    function perfil(){
        $idPerfil = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
        if(isset($_SESSION['idUsuario'])){
            $idUsuario=$_SESSION['idUsuario'];
        }else{
            $idUsuario=0;
        }       
        $anuncioDAO = new AnuncioDAO(ConexionBD::conectar());
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $comentarioDAO = new ComentarioDAO(ConexionBD::conectar());
        $likesDAO = new LikesDAO(ConexionBD::conectar());
        $seguidorDAO = new SeguidorDAO(ConexionBD::conectar());
        //Obtengo todos los mensajes de la BD
        $anuncios = $anuncioDAO->obtenerPorIdUsuario($idPerfil);
        $comentarios = $comentarioDAO->obtenerTodos();
        $usuarios = $usuarioDAO->obtenerUsuarios();
        $likes = $likesDAO->obtenerTodos();
        $seguidores = $seguidorDAO->obtenerTodos();
        $nombreU=$usuarioDAO->obtenerUsu($idPerfil);
        
        //Incluimos la vista
        require 'app/vistas/perfil.php';
    }
    function personas(){     
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $seguidorDAO = new SeguidorDAO(ConexionBD::conectar());
        //Obtengo todos los mensajes de la BD
        $usuarios = $usuarioDAO->obtenerUsuarios();
        $seguidores = $seguidorDAO->obtenerTodos();
        
        //Incluimos la vista
        require 'app/vistas/personas.php';
    }
    function paraTi(){
        if(isset($_SESSION['idUsuario'])){
            $idUsuario=$_SESSION['idUsuario'];
        }else{
            $idUsuario=0;
        }       
        $anuncioDAO = new AnuncioDAO(ConexionBD::conectar());
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $comentarioDAO = new ComentarioDAO(ConexionBD::conectar());
        $seguidorDAO = new SeguidorDAO(ConexionBD::conectar());
        $likesDAO = new LikesDAO(ConexionBD::conectar());
        //Obtengo todos los mensajes de la BD
        $anuncios = $anuncioDAO->obtenerTodos();
        $seguidores = $seguidorDAO->obtenerTodos();
        $comentarios = $comentarioDAO->obtenerTodos();
        $usuarios = $usuarioDAO->obtenerUsuarios();
        $likes = $likesDAO->obtenerTodos();
        
        //Incluimos la vista
        require 'app/vistas/paraTi.php';
    }
    function tendencias(){
        if(isset($_SESSION['idUsuario'])){
            $idUsuario=$_SESSION['idUsuario'];
        }else{
            $idUsuario=0;
        }       
        $anuncioDAO = new AnuncioDAO(ConexionBD::conectar());
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $comentarioDAO = new ComentarioDAO(ConexionBD::conectar());
        $likesDAO = new LikesDAO(ConexionBD::conectar());
        //Obtengo todos los mensajes de la BD
        $anuncios = $anuncioDAO->obtenerAnunciosMasGustados();
        $comentarios = $comentarioDAO->obtenerTodos();
        $usuarios = $usuarioDAO->obtenerUsuarios();
        $likes = $likesDAO->obtenerTodos();
        
        //Incluimos la vista
        require 'app/vistas/tendencias.php';
    }
    function unAnuncio(){
        $idAnuncio = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
        $anuncioDAO = new AnuncioDAO(ConexionBD::conectar());
        $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
        $comentarioDAO = new ComentarioDAO(ConexionBD::conectar());
        $likesDAO = new LikesDAO(ConexionBD::conectar());
        
        //Obtengo todos los mensajes de la BD
        if(!$anuncio = $anuncioDAO->obtener($idAnuncio)){   //Si el mensaje no existe...
            header("Location: index.php");
            die(); 
        }
        $comentarios = $comentarioDAO->obtenerTodos();
        $likes = $likesDAO->obtenerTodos();
        $anuncio = $anuncioDAO->obtener($idAnuncio);
        $usuarios = $usuarioDAO->obtenerUsuarios();
        $usuario = $usuarioDAO->obtenerUsu($anuncio->getIdUsuario());
        
        //Incluimos la vista
        require 'app/vistas/unAnuncio.php';
    }
    function borrar_ajax(){
        //Inicializo las variables necesarias
        $idUsuario=$_SESSION['idUsuario'];
        $idAnuncio = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
        
        //Obtengo el mensaje de la base de datos a partir del idMensaje
        $anuncioDAO = new AnuncioDAO(ConexionBD::conectar());
        $anuncio = $anuncioDAO->obtener($idAnuncio);
        if(!$anuncio = $anuncioDAO->obtener($idAnuncio)){   //Si el mensaje no existe...
            print json_encode(["borrado" => false, "anuncio" =>"El anuncio no existe"]);
            die(); 
        }
        if($anuncio->getIdUsuario()!=$idUsuario){
            header("Location: index.php");
            die();
        }            
        
        //Borro el mensaje
        if($anuncioDAO->borrar($anuncio)){
            print json_encode(["borrado"=>true]);
        }else{
            print json_encode(["borrado"=>false]);
        }
        
    }   
    function anuncio_ajax() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {          
            $descripcion = htmlentities($_POST['descripcion']);
            $titulo = htmlentities($_POST['titulo']);  
            $anuncio = new Anuncio();
            $anuncio->setDescripcion($descripcion);
            $anuncio->setTitulo($titulo);
            $anuncio->setIdUsuario($_SESSION['idUsuario']);

            $anuncioDAO = new AnuncioDAO(ConexionBD::conectar());
            $idAnuncio = $anuncioDAO->insertar($anuncio);
            $anuncioBD = $anuncioDAO->obtener($idAnuncio);
            $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());
            $usuarios= $usuarioDAO->obtenerUsuarios();
            $nombreU = ""; // Variable para almacenar el nombre de usuario correspondiente
            foreach ($usuarios as $u) {
                if ($_SESSION['idUsuario'] == $u->getId()) {
                    $nombreU = $u->getNombre();
                    break; // Se encontró el nombre de usuario, se puede salir del bucle
                }
            }
            //Indicar al navegador que la respuesta es un json
            header("Content-type: application/json; charset=utf-8");
            print json_encode(array("resultado"=>true,"nombreU"=>$nombreU, "anuncio" =>$anuncioBD->toArray())) ;
            //print json_encode(["resultado"=>true, "mensaje" =>$mensajeBD->toArray()]) ;
        }
    }
    function comentario_ajax() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $contenido = htmlentities($_POST['comentario']);
            $idUsuario=$_SESSION['idUsuario'];
            $idAnuncio= htmlentities($_POST['idAnuncio']);
            
            $comentario = new Comentario();
            $comentario->setComentario($contenido);
            $comentario->setIdAnuncio($idAnuncio);
            $comentario->setIdUsuarioComenta($idUsuario);

            $comentarioDAO = new ComentarioDAO(ConexionBD::conectar());
            $idComentario = $comentarioDAO->insertar($comentario);
            $comentarioBD = $comentarioDAO->obtener($idComentario);
            $usuarioDAO = new UsuarioDAO(ConexionBD::conectar());         
            $usu= $usuarioDAO->obtenerUsu($comentario->getIdUsuarioComenta());
            $nombreUsu= $usu->getNombre();
            //Indicar al navegador que la respuesta es un json
            header("Content-type: application/json; charset=utf-8");
            $response = array(
                "resultado" => true,
                "comentario" => $comentarioBD->toArray(),
                "nombreUsu" => $nombreUsu
            );
            // Imprimir la respuesta JSON
            print json_encode($response);
        }
    }
    // Controlador para insertar o borrar un like
    public function insertarBorrarLike() {
      $idAnuncio = $_GET['idAnuncio'];
      $idUsuario=$_SESSION['idUsuario']; // Suponiendo que tienes una variable de sesión con el ID del usuario actual
      $likesDAO = new LikesDAO(ConexionBD::conectar());
      // Verifica si el usuario ya ha dado like al anuncio
      $likeExistente = $likesDAO->buscarPorAnuncioYUsuario($idAnuncio, $idUsuario);

      if ($likeExistente) {
        // Si ya existe el like, bórralo
        $borrado = $likesDAO->borrar($likeExistente);

        if ($borrado) {
          $contadorLikes2 = $likesDAO->obtenerLikesPorIdAnuncio($idAnuncio);
          $response = array('success' => true, 'contadorLikes' => $contadorLikes2);
        } else {
          $response = array('success' => false);
        }
      } else {
        // Si no existe el like, créalo


        $likeNuevo = new Likes();
        $likeNuevo->setIdAnuncio($idAnuncio);
        $likeNuevo->setIdUsuarioDaLike($idUsuario);
        $insertado = $likesDAO->insertar($likeNuevo);

        if ($insertado) {
            $contadorLikes = $likesDAO->obtenerLikesPorIdAnuncio($idAnuncio);
            $response = array('success' => true, 'contadorLikes' => $contadorLikes);
        } else {
            $response = array('success' => false);
        }
      }

      header('Content-Type: application/json');
      echo json_encode($response);
    }
    public function insertarBorrarSeguir() {
        $idUsuario = $_GET['idUsuario'];
        $idUsuarioActual = $_SESSION['idUsuario'];
        $seguidorDAO = new SeguidorDAO(ConexionBD::conectar());

        // Verifica si el usuario actual ya sigue al usuario dado
        $esSeguido = $seguidorDAO->buscarPorSeguidorYUsuario($idUsuarioActual, $idUsuario);

        if ($esSeguido) {
          // Si ya sigue al usuario, elimina el seguidor
          $eliminado = $seguidorDAO->borrar($esSeguido);

          if ($eliminado) {
            $contadorSeguidores = $seguidorDAO->obtenerSeguidoresPorIdUsuario($idUsuario);
            $response = array('success' => true, 'isFollowing' => false, 'followerCount' => $contadorSeguidores);
          } else {
            $response = array('success' => false);
          }
        } else {
          // Si no sigue al usuario, crea un nuevo seguidor
          $nuevoSeguidor = new Seguidor();
          $nuevoSeguidor->setIdSeguidor($idUsuarioActual);
          $nuevoSeguidor->setIdSiguiendo($idUsuario);
          $insertado = $seguidorDAO->insertar($nuevoSeguidor);

          if ($insertado) {
            $contadorSeguidores = $seguidorDAO->obtenerSeguidoresPorIdUsuario($idUsuario);
            $response = array('success' => true, 'isFollowing' => true, 'followerCount' => $contadorSeguidores);
          } else {
            $response = array('success' => false);
          }
        }

        echo json_encode($response);
    }
}
