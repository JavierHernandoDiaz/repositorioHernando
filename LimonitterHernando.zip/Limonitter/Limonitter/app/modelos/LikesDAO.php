<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of LikesDAO
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2. 
 */
class LikesDAO {
    
    private $conn;

    public function __construct($conn) {
        if (!$conn instanceof mysqli) { //Comprueba si $conn es un objeto de la clase mysqli
            return false;
        }
        $this->conn = $conn;
    }

    public function insertar(Likes $s) {
        $sql = "INSERT INTO likes (idAnuncio, idUsuarioDaLike) VALUES (?,?)";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $idAnuncio = $s->getIdAnuncio();
        $idUsuarioDaLike = $s->getIdUsuarioDaLike();
        
        $stmt->bind_param('ii', $idAnuncio, $idUsuarioDaLike);
        $stmt->execute();
        return $stmt->insert_id;
    }
    
    public function borrar(Likes $s) {
        $sql = "DELETE FROM likes WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }   
        $id = $s->getId();
        $stmt->bind_param('i', $id);
        $stmt->execute();
        
        if($stmt->affected_rows==0){
            return false;
        }
        else{
            return true;
        }
    }
    
    public function obtenerTodos() {
        $sql = "SELECT * FROM likes";
        if (!$result = $this->conn->query($sql)) {
            die("Error al ejecutar la SQL " . $this->conn->error);
        }
        $array_likes = array();
        while ($like = $result->fetch_object('Likes')) {
            $array_likes[] = $like;
        }
        return $array_likes;
    }
    public function buscarPorAnuncioYUsuario($idAnuncio, $idUsuario) {
        $sql = "SELECT * FROM likes WHERE idAnuncio = ? AND idUsuarioDaLike = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
          die("Error al preparar la sentencia: " . $this->conn->error);
        }

        $stmt->bind_param('ii', $idAnuncio, $idUsuario);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
          // El like existe, devuelve el objeto del like encontrado
          $like = $result->fetch_object('Likes');
          return $like;
        } else {
          // No se encontró el like, devuelve null o false según tu preferencia
          return null;
        }
    }
    public function obtenerLikesPorIdAnuncio($idAnuncio) {
         $sql = "SELECT COUNT(*) as contador FROM likes WHERE idAnuncio = ?";
  if (!$stmt = $this->conn->prepare($sql)) {
    die("Error al preparar la sentencia: " . $this->conn->error);
  }

  $stmt->bind_param('i', $idAnuncio);
  $stmt->execute();

  $result = $stmt->get_result();
  $contadorLikes = 0;
  if ($row = $result->fetch_assoc()) {
    $contadorLikes = $row['contador'];
  }

  return $contadorLikes;
    }
}
