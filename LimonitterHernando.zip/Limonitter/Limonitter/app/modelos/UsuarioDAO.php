<?php
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class UsuarioDAO {
    private $conn;
    
    public function __construct($conn) {
        if(!$conn instanceof mysqli){
            echo "Error: No se pudo conectar a MySQL . Error" . mysqli_connect_errno() . " : ". mysqli_connect_error() . PHP_EOL;  
            return false;
        }
        $this->conn=$conn;        
    }
    
    public function obtenerUsuarios() {
        $sql="SELECT * FROM usuario";
        if(!$result=$this->conn->query($sql)){
            die("Error al ejecutar la SQL ".$this->conn->error);
        }
        $arrayusu= array();
        while($usuarios = $result->fetch_object('Usuario')){
            $arrayusu[]= $usuarios;
        }
        return $arrayusu;
    }
    public function obtenerUsu(int $id){
        $sql="SELECT * FROM usuario WHERE id= ?";
        if(!$stmt=$this->conn->prepare($sql)){
            die("Error al ejecutar la SQL ".$this->conn->error);
        }
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result=$stmt->get_result();    
        return $result->fetch_object('Usuario');
    }
    public function insertar(Usuario $s) {
        $sql = "INSERT INTO usuario (email, password ,nombre, uid) VALUES (?,?,?,?)";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $email = $s->getEmail();
        $password = $s->getPassword();
        $nombre = $s->getNombre();
        $uid = $s->getUid();
        $stmt->bind_param('ssss', $email, $password, $nombre,$uid);
        $stmt->execute();
    }
    public function obtenerUsuarioEmail(String $email) {
        $sql="SELECT * FROM usuario WHERE email = ?";
        if(!$stmt=$this->conn->prepare($sql)){
            die("Error al ejecutar la SQL ".$this->conn->error);
        }
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result=$stmt->get_result();    
        return $result->fetch_object('Usuario');
    }
    public function actualizar(Usuario $u) {
        $sql = "UPDATE usuario SET email = ? , uid = ?"
                ." WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $id = $u->getId();
        $email = $u->getEmail();
        $uid = $u->getUid();
        $stmt->bind_param('ssi', $email, $uid, $id);
        $stmt->execute();
    }
    public function obtenerPorUid($uid) {
        $sql = "SELECT * FROM usuario WHERE uid = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $stmt->bind_param('i', $uid);
        $stmt->execute();

        $result = $stmt->get_result();
        $usuario = $result->fetch_object('Usuario');
        //Para que netbeans reconozca el objeto de la clase Usuario  
        return $usuario;
    }
    public function actualizarContraseña($idUsuario, $nuevaContraseña) {
        $sql = "UPDATE usuario SET password = ? WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $stmt->bind_param('si', $nuevaContraseña, $idUsuario);
        $stmt->execute();
    }
}
