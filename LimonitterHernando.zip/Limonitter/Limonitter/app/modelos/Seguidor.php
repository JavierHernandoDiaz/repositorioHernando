<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Seguidor
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class Seguidor {
    private $id;
    private $idSeguidor;
    private $idSiguiendo;
    
    public function getId() {
        return $this->id;
    }

    public function getIdSeguidor() {
        return $this->idSeguidor;
    }

    public function getIdSiguiendo() {
        return $this->idSiguiendo;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setIdSeguidor($idSeguidor): void {
        $this->idSeguidor = $idSeguidor;
    }

    public function setIdSiguiendo($idSiguiendo): void {
        $this->idSiguiendo = $idSiguiendo;
    }


}
