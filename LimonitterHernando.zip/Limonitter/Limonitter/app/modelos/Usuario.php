<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Usuario
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class Usuario {
    private $id;
    private $email;
    private $password;
    private $nombre;
    private $uid;
    
    public function getId() {
        return $this->id;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getUid() {
        return $this->uid;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setEmail($email): void {
        $this->email = $email;
    }

    public function setPassword($password): void {
        $this->password = $password;
    }

    public function setNombre($nombre): void {
        $this->nombre = $nombre;
    }

    public function setUid($uid): void {
        $this->uid = $uid;
    }

}
