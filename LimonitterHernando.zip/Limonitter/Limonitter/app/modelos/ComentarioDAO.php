<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of ComentarioDAO
 *
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class ComentarioDAO {
    
    private $conn;

    public function __construct($conn) {
        if (!$conn instanceof mysqli) { //Comprueba si $conn es un objeto de la clase mysqli
            return false;
        }
        $this->conn = $conn;
    }

    public function insertar(Comentario $s) {
        $sql = "INSERT INTO comentario (idAnuncio, idUsuarioComenta, comentario) VALUES (?,?,?)";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $idAnuncio = $s->getIdAnuncio();
        $idUsuarioComenta = $s->getIdUsuarioComenta();
        $comentario = $s->getComentario();
        
        $stmt->bind_param('iis', $idAnuncio, $idUsuarioComenta, $comentario);
        $stmt->execute();
        return $stmt->insert_id;
    }
    
    public function borrar(Comentario $s) {
        $sql = "DELETE FROM comentario WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }   
        $id = $s->getId();
        $stmt->bind_param('i', $id);
        $stmt->execute();
        
        if($stmt->affected_rows==0){
            return false;
        }
        else{
            return true;
        }
    }
    
    public function obtenerTodos() {
        $sql = "SELECT * FROM comentario";
        if (!$result = $this->conn->query($sql)) {
            die("Error al ejecutar la SQL " . $this->conn->error);
        }
        $array_comentarios = array();
        while ($comentario = $result->fetch_object('Comentario')) {
            $array_comentarios[] = $comentario;
        }
        return $array_comentarios;
    }
     public function obtener(int $id) {
        $sql = "SELECT * FROM comentario WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $stmt->bind_param('i', $id);
        $stmt->execute();
        
        $result = $stmt->get_result();
        
        return $result->fetch_object('Comentario');
    }
}
