<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of SeguidorDAO
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class SeguidorDAO {
    
    private $conn;

    public function __construct($conn) {
        if (!$conn instanceof mysqli) { //Comprueba si $conn es un objeto de la clase mysqli
            return false;
        }
        $this->conn = $conn;
    }

    public function insertar(Seguidor $s) {
        $sql = "INSERT INTO seguidor (idSeguidor, idSiguiendo) VALUES (?,?)";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $idSeguidor = $s->getIdSeguidor();
        $idSiguiendo = $s->getIdSiguiendo();
        
        $stmt->bind_param('ii', $idSeguidor, $idSiguiendo);
        $stmt->execute();
        return $stmt->insert_id;
    }
    
    public function borrar(Seguidor $s) {
        $sql = "DELETE FROM seguidor WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }   
        $id = $s->getId();
        $stmt->bind_param('i', $id);
        $stmt->execute();
        
        if($stmt->affected_rows==0){
            return false;
        }
        else{
            return true;
        }
    }
    
    public function obtenerTodos() {
        $sql = "SELECT * FROM seguidor";
        if (!$result = $this->conn->query($sql)) {
            die("Error al ejecutar la SQL " . $this->conn->error);
        }
        $array_seguidores = array();
        while ($seguidor = $result->fetch_object('Seguidor')) {
            $array_seguidores[] = $seguidor;
        }
        return $array_seguidores;
    }
    public function buscarPorSeguidorYUsuario($idSeguidor, $idUsuario) {
        $sql = "SELECT * FROM seguidor WHERE idSeguidor = ? AND idSiguiendo = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
          die("Error al preparar la sentencia: " . $this->conn->error);
        }

        $stmt->bind_param('ii', $idSeguidor, $idUsuario);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
          // El seguidor existe, devuelve el objeto del seguidor encontrado
          $seguidor = $result->fetch_object('Seguidor');
          return $seguidor;
        } else {
          // No se encontró el seguidor, devuelve null o false según tu preferencia
          return null;
        }
      }

    public function obtenerSeguidoresPorIdUsuario($idUsuario) {
        $sql = "SELECT COUNT(*) as contador FROM seguidor WHERE idSiguiendo = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
          die("Error al preparar la sentencia: " . $this->conn->error);
        }

        $stmt->bind_param('i', $idUsuario);
        $stmt->execute();

        $result = $stmt->get_result();
        $contadorSeguidores = 0;
        if ($row = $result->fetch_assoc()) {
          $contadorSeguidores = $row['contador'];
        }

        return $contadorSeguidores;
    }
}
