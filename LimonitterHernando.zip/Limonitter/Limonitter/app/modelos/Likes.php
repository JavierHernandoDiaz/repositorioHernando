<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Likes
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class Likes {
    private $id;
    private $idAnuncio;
    private $idUsuarioDaLike;
    
    public function getId() {
        return $this->id;
    }

    public function getIdAnuncio() {
        return $this->idAnuncio;
    }

    public function getIdUsuarioDaLike() {
        return $this->idUsuarioDaLike;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setIdAnuncio($idAnuncio): void {
        $this->idAnuncio = $idAnuncio;
    }

    public function setIdUsuarioDaLike($idUsuarioDaLike): void {
        $this->idUsuarioDaLike = $idUsuarioDaLike;
    }


}
