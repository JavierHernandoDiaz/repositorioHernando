<?php

/**
 * Description of AnuncioDAO
 *
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class AnuncioDAO {

    private $conn;

    public function __construct($conn) {
        if (!$conn instanceof mysqli) { //Comprueba si $conn es un objeto de la clase mysqli
            return false;
        }
        $this->conn = $conn;
    }

    public function insertar(Anuncio $a) {
        $sql = "INSERT INTO anuncio (titulo, descripcion, idUsuario) VALUES (?,?,?)";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $titulo = $a->getTitulo();
        $descripcion = $a->getDescripcion();
        $idUsuario = $a->getIdUsuario();
        
        $stmt->bind_param('ssi', $titulo, $descripcion, $idUsuario);
        $stmt->execute();
        return $stmt->insert_id;
    }

    /**
     * Obtiene un mensaje de la base de datos
     * @param int $id id del mensaje a obtener
     * @return Mensaje  Objeto mensaje o false si no existe
     */
    public function obtener(int $id) {
        $sql = "SELECT * FROM anuncio WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }
        $stmt->bind_param('i', $id);
        $stmt->execute();
        
        $result = $stmt->get_result();
        
        return $result->fetch_object('Anuncio');
    }

    /**
     * Borra un mensaje de la base de datos
     * @return boolean Devuelve true si ha borrado un mensaje y false en caso contrario
     */
    public function borrar(Anuncio $a) {
        $sql = "DELETE FROM anuncio WHERE id = ?";
        if (!$stmt = $this->conn->prepare($sql)) {
            die("Error al preparar la sentencia: " . $this->conn->error);
        }   
        $id = $a->getId();
        $stmt->bind_param('i', $id);
        $stmt->execute();
        
        if($stmt->affected_rows==0){
            return false;
        }
        else{
            return true;
        }
    }

    public function obtenerTodos() {
        $sql = "SELECT * FROM anuncio ORDER BY fecha DESC";
        if (!$result = $this->conn->query($sql)) {
            die("Error al ejecutar la SQL " . $this->conn->error);
        }
        $array_anuncios = array();
        while ($anuncio = $result->fetch_object('Anuncio')) {
            $array_anuncios[] = $anuncio;
        }
        return $array_anuncios;
    }
    public function obtenerAnunciosMasGustados($limit = 4) {
        $sql = "SELECT a.*
                FROM anuncio a
                LEFT JOIN likes l ON a.id = l.idAnuncio
                GROUP BY a.id
                ORDER BY COUNT(l.idAnuncio) DESC
                LIMIT ?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('i', $limit);
        $stmt->execute();

        $result = $stmt->get_result();
        $anuncios = array();

        while ($row = $result->fetch_assoc()) {
          $anuncio = new Anuncio();
          $anuncio->setId($row['id']);
          $anuncio->setTitulo($row['titulo']);
          $anuncio->setDescripcion($row['descripcion']);
          $anuncio->setFecha($row['fecha']);
          $anuncio->setIdUsuario($row['idUsuario']);
          // Agrega los demás setters según las propiedades de la clase Anuncio

          $anuncios[] = $anuncio;
        }

        return $anuncios;
    }
    public function obtenerPorIdUsuario($idUsuario) {
        $sql = "SELECT * FROM anuncio WHERE idUsuario = ? ORDER BY fecha DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $idUsuario);
        $stmt->execute();
        $result = $stmt->get_result();

        $array_anuncios = array();
        while ($anuncio = $result->fetch_object('Anuncio')) {
            $array_anuncios[] = $anuncio;
        }

        return $array_anuncios;
    }
}
