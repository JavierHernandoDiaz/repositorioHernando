<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Comentario
 *
 * @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */
class Comentario {
    private $id;
    private $idAnuncio;
    private $IdUsuarioComenta;
    private $comentario;
    
    public function getId() {
        return $this->id;
    }

    public function getIdAnuncio() {
        return $this->idAnuncio;
    }

    public function getIdUsuarioComenta() {
        return $this->IdUsuarioComenta;
    }

    public function getComentario() {
        return $this->comentario;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setIdAnuncio($idAnuncio): void {
        $this->idAnuncio = $idAnuncio;
    }

    public function setIdUsuarioComenta($IdUsuarioComenta): void {
        $this->IdUsuarioComenta = $IdUsuarioComenta;
    }

    public function setComentario($comentario): void {
        $this->comentario = $comentario;
    }

    function toArray() {
        $array = [
            'id' => $this->id,         
            'idAnuncio' => $this->idAnuncio,
            'IdUsuarioComenta' => $this->IdUsuarioComenta,
            'comentario' => $this->comentario
        ];
        return $array;
    }
}
