<?php
define("MYSQL_USER", "root");
define("MYSQL_PASS", "");
define("MYSQL_HOST", "localhost");
define("MYSQL_BD", "limonitter");
//Constantes de conexion MySql
/* @author Javier Hernando Diaz
 * @date 06/06/23
 * @version 2.0
 */